# Stream trong java 8

Created by: Khánh Linh Phạm
Created time: July 15, 2024 4:51 PM

## Giới thiệu

- Java Streams là một phần của java 8, nó cung cấp một cách hiệu quả và dễ đọc để xử lý các tập hợp dữ liệu. Streams cho phép thực hiện các thao tác như lọc, biến đổi, và thu thập dữ liệu mà không cần phải viết nhiều mã lặp.

## Các hàm trong Stream

1. Stream():
    1. Phương thức này chuyển đổi một Collection( ví dụ như (List, Set) thành một Stream. Nó cho phép chúng ta sử dụng các phương thức Stream khác để thao tác trên dữ liệu.
2. map(Function<? super T, ? extends R> mapper):
    1. dùng để biến đổi kiểu dữ liệu này sang kiểu dữ liệu khác. Nó nhận một Fuction làm tham số, với mỗi phần tử trọng Stream, nó sẽ áp dụng Function này và trả về một Stream với các phần đã biến đổi.
3. `collect(Collector<? super T, A,R>collector):`
    1. Phương thức này được sử dụng để thu thập các phần tử của stream vào một Collection hoặc một kiểu dữ liệu khác. THông thường, ‘Collectors’ được dùng để cung cấp các phương thức thu thập.
    
    ## Vi dụ minh họa
    

![Untitled](Stream%20trong%20java%208%20ee941d3dc2ec43629d251ca94bc60d2c/Untitled.png)

Chi tiết:

![Untitled](Stream%20trong%20java%208%20ee941d3dc2ec43629d251ca94bc60d2c/Untitled%201.png)

![Untitled](Stream%20trong%20java%208%20ee941d3dc2ec43629d251ca94bc60d2c/Untitled%202.png)

- Với mỗi phần tử `item` trong Stream, ta biến đổi nó thành một đối tượng `buildingDTO`.
- `rentAreaRe.getValueById(item.getId())` trả về một danh sách `rentAreaEntity`, sau đó chúng ta lại tạo một Stream từ danh sách này.
- `rentAreaEntity::getValue` là một method reference đến phương thức `getValue` của `rentAreaEntity`. Nó được sử dụng để lấy giá trị `value` từ mỗi phần tử `rentAreaEntity`.
- `Object::toString` là một method reference đến phương thức `toString` của lớp `Object`, nó được sử dụng để chuyển đổi giá trị sang chuỗi.

![Untitled](Stream%20trong%20java%208%20ee941d3dc2ec43629d251ca94bc60d2c/Untitled%203.png)