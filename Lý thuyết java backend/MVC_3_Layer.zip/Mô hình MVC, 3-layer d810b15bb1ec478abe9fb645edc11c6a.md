# Mô hình MVC, 3-layer

Created by: Khánh Linh Phạm
Created time: July 15, 2024 10:51 AM

## Vì sao phải dùng mô hình mvc, 3-layer:

- Code quá nhiều( Vi phạm yêu cầu SOLID).
- Người đến sau đọc sẽ không thể hiểu gì cả, rất lâu để debug.

![Untitled](Mo%CC%82%20hi%CC%80nh%20MVC,%203-layer%20d810b15bb1ec478abe9fb645edc11c6a/Untitled.png)

- Presentation layer: chứa controller, ⇒ @RestController ⇒ Controller class.
- Business Logic Layer: ⇒ @Serivce ⇒ service class xử lý dữ liệu đầu ra theo yêu cầu của client.
- Data Access layer: ⇒ @Repository (Entity hứng dữ liệu ResultSet trả ra map 1:1 DB )⇒ Repository class: tầng thao tác với db.

## Các thành phần trong mô hình MVC:

- Model:
    - Có nhiệm vụ thao tác với db.
    - Nó chứa tất cả các hàm, các phương thức truy vấn trực tiếp với dữ liệu.
    - Controller sẽ thông quá các hàm, phương thức đó để lấy dữ liệu rồi gửi qua view.
- View:
    - Lao giao diện người dùng ( user interface).
    - Chứa các thành phần tương tác với người dùng như menu, button, image, text,…
    - Nơi nhận dữ liệu từ Controller và hiện thị.
- Controller:
    - Là thành phần trong gian giữa Model và View.
    - Đảm nhận via trò tiếp nhận yêu cầu từ người dùng, thông qua model để lấy dữ liệu sau đó thông qua view để hiện thị cho người dùng.

## Các công việc trong 3 layer:

- Lấy dữ liệu lên: JDBC →JPA → Spring Data JPA
    - **ResultSet → (java Bean)Entity(map1:1 với DB) → Filter(xử lý logic) → DTO(model) → View**
- Update dữ liệu:
    - **View → DTO(Model) → Filter → Entity → DB**